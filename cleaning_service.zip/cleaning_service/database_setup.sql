-- =====================================================
-- HOME CLEANING SERVICE DATABASE
-- Anna Johnson
-- Execute this in phpMyAdmin
-- =====================================================

-- Create database
CREATE DATABASE IF NOT EXISTS cleaning_service;
USE cleaning_service;

-- =====================================================
-- 1. CLIENTS TABLE
-- =====================================================
CREATE TABLE clients (
    client_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    address VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    cc_number_encrypted VARCHAR(255) NOT NULL,
    cc_expiry VARCHAR(7) NOT NULL,
    cc_cvv_encrypted VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email)
) ENGINE=InnoDB;

-- =====================================================
-- 2. SERVICE REQUESTS TABLE
-- =====================================================
CREATE TABLE service_requests (
    request_id INT AUTO_INCREMENT PRIMARY KEY,
    client_id INT NOT NULL,
    service_address VARCHAR(255) NOT NULL,
    cleaning_type ENUM('basic', 'deep_cleaning', 'move_out') NOT NULL,
    num_rooms INT NOT NULL,
    preferred_date DATE NOT NULL,
    preferred_time TIME NOT NULL,
    proposed_budget DECIMAL(10,2) NOT NULL,
    notes TEXT,
    status ENUM('pending', 'negotiating', 'accepted', 'rejected', 'canceled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(client_id) ON DELETE CASCADE,
    INDEX idx_status (status),
    INDEX idx_client (client_id)
) ENGINE=InnoDB;

-- =====================================================
-- 3. REQUEST PHOTOS TABLE (max 5 per request)
-- =====================================================
CREATE TABLE request_photos (
    photo_id INT AUTO_INCREMENT PRIMARY KEY,
    request_id INT NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES service_requests(request_id) ON DELETE CASCADE,
    INDEX idx_request (request_id)
) ENGINE=InnoDB;

-- =====================================================
-- 4. QUOTE RESPONSES TABLE (ALL stored for evidence)
-- =====================================================
CREATE TABLE quote_responses (
    response_id INT AUTO_INCREMENT PRIMARY KEY,
    request_id INT NOT NULL,
    responder ENUM('anna', 'client') NOT NULL,
    response_type ENUM('quote', 'rejection', 'counter', 'accept', 'cancel') NOT NULL,
    adjusted_price DECIMAL(10,2) NULL,
    scheduled_date DATE NULL,
    scheduled_time_start TIME NULL,
    scheduled_time_end TIME NULL,
    note TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES service_requests(request_id) ON DELETE CASCADE,
    INDEX idx_request (request_id),
    INDEX idx_created (created_at)
) ENGINE=InnoDB;

-- =====================================================
-- 5. ORDERS TABLE (created when quote accepted)
-- =====================================================
CREATE TABLE orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    request_id INT NOT NULL UNIQUE,
    final_price DECIMAL(10,2) NOT NULL,
    scheduled_date DATE NOT NULL,
    scheduled_time_start TIME NOT NULL,
    scheduled_time_end TIME NOT NULL,
    status ENUM('scheduled', 'in_progress', 'completed', 'canceled') DEFAULT 'scheduled',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    FOREIGN KEY (request_id) REFERENCES service_requests(request_id) ON DELETE CASCADE,
    INDEX idx_status (status),
    INDEX idx_scheduled (scheduled_date)
) ENGINE=InnoDB;

-- =====================================================
-- 6. BILLS TABLE
-- =====================================================
CREATE TABLE bills (
    bill_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    description TEXT,
    status ENUM('pending', 'disputed', 'paid') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    paid_at TIMESTAMP NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    INDEX idx_order (order_id),
    INDEX idx_status (status)
) ENGINE=InnoDB;

-- =====================================================
-- 7. BILL RESPONSES TABLE (ALL stored for evidence)
-- =====================================================
CREATE TABLE bill_responses (
    response_id INT AUTO_INCREMENT PRIMARY KEY,
    bill_id INT NOT NULL,
    responder ENUM('anna', 'client') NOT NULL,
    response_type ENUM('dispute', 'revision', 'payment') NOT NULL,
    revised_amount DECIMAL(10,2) NULL,
    note TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bill_id) REFERENCES bills(bill_id) ON DELETE CASCADE,
    INDEX idx_bill (bill_id),
    INDEX idx_created (created_at)
) ENGINE=InnoDB;

-- =====================================================
-- 8. ADMIN TABLE (Anna's login)
-- =====================================================
CREATE TABLE admin (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =====================================================
-- INSERT DEFAULT ADMIN (password: admin123)
-- Change this password in production!
-- =====================================================
INSERT INTO admin (username, password_hash, name) 
VALUES ('anna', '$2y$10$8K1p6IXFL.1xpkVVXQ1pXuhNfxGVXLGBW5G5TsLUDr.Ov3z3JhFFC', 'Anna Johnson');

-- =====================================================
-- SAMPLE CLIENT FOR TESTING (password: client123)
-- =====================================================
INSERT INTO clients (first_name, last_name, address, phone, email, password_hash, cc_number_encrypted, cc_expiry, cc_cvv_encrypted)
VALUES ('John', 'Doe', '123 Main St, City, ST 12345', '555-123-4567', 'john@example.com', 
        '$2y$10$8K1p6IXFL.1xpkVVXQ1pXuhNfxGVXLGBW5G5TsLUDr.Ov3z3JhFFC',
        'encrypted_number', '12/25', 'encrypted_cvv');

-- =====================================================
-- VIEWS FOR REPORTING
-- =====================================================

-- View: All requests with client info
CREATE OR REPLACE VIEW v_requests_full AS
SELECT 
    sr.*,
    c.first_name,
    c.last_name,
    c.email,
    c.phone,
    CONCAT(c.first_name, ' ', c.last_name) AS client_name
FROM service_requests sr
JOIN clients c ON sr.client_id = c.client_id;

-- View: Orders with request and client info
CREATE OR REPLACE VIEW v_orders_full AS
SELECT 
    o.*,
    sr.service_address,
    sr.cleaning_type,
    sr.num_rooms,
    c.first_name,
    c.last_name,
    c.email,
    c.phone,
    CONCAT(c.first_name, ' ', c.last_name) AS client_name
FROM orders o
JOIN service_requests sr ON o.request_id = sr.request_id
JOIN clients c ON sr.client_id = c.client_id;

-- View: Bills with order and client info
CREATE OR REPLACE VIEW v_bills_full AS
SELECT 
    b.*,
    o.final_price AS order_price,
    o.scheduled_date,
    sr.service_address,
    sr.cleaning_type,
    c.first_name,
    c.last_name,
    c.email,
    CONCAT(c.first_name, ' ', c.last_name) AS client_name
FROM bills b
JOIN orders o ON b.order_id = o.order_id
JOIN service_requests sr ON o.request_id = sr.request_id
JOIN clients c ON sr.client_id = c.client_id;
