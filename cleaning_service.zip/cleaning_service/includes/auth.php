<?php
/**
 * Authentication Helper Functions
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if client is logged in
function isClientLoggedIn() {
    return isset($_SESSION['client_id']) && !empty($_SESSION['client_id']);
}

// Check if admin is logged in
function isAdminLoggedIn() {
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

// Require client login - redirect if not
function requireClientLogin() {
    if (!isClientLoggedIn()) {
        header('Location: /cleaning_service/client/login.php');
        exit;
    }
}

// Require admin login - redirect if not
function requireAdminLogin() {
    if (!isAdminLoggedIn()) {
        header('Location: /cleaning_service/admin/login.php');
        exit;
    }
}

// Get current client ID
function getClientId() {
    return $_SESSION['client_id'] ?? null;
}

// Get current admin ID
function getAdminId() {
    return $_SESSION['admin_id'] ?? null;
}

// Logout client
function logoutClient() {
    unset($_SESSION['client_id']);
    unset($_SESSION['client_name']);
    session_destroy();
}

// Logout admin
function logoutAdmin() {
    unset($_SESSION['admin_id']);
    unset($_SESSION['admin_name']);
    session_destroy();
}
?>
