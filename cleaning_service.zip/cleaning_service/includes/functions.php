<?php
/**
 * Helper Functions
 */

// Sanitize input
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Format currency
function formatMoney($amount) {
    return '$' . number_format($amount, 2);
}

// Format date
function formatDate($date) {
    return date('M d, Y', strtotime($date));
}

// Format time
function formatTime($time) {
    return date('g:i A', strtotime($time));
}

// Format datetime
function formatDateTime($datetime) {
    return date('M d, Y g:i A', strtotime($datetime));
}

// Get status badge HTML
function getStatusBadge($status) {
    $colors = [
        'pending' => 'warning',
        'negotiating' => 'info',
        'accepted' => 'success',
        'rejected' => 'danger',
        'canceled' => 'secondary',
        'scheduled' => 'primary',
        'in_progress' => 'info',
        'completed' => 'success',
        'disputed' => 'warning',
        'paid' => 'success'
    ];
    $color = $colors[$status] ?? 'secondary';
    return "<span class='badge bg-{$color}'>" . ucfirst(str_replace('_', ' ', $status)) . "</span>";
}

// Get cleaning type display name
function getCleaningTypeName($type) {
    $types = [
        'basic' => 'Basic Cleaning',
        'deep_cleaning' => 'Deep Cleaning',
        'move_out' => 'Move-Out Cleaning'
    ];
    return $types[$type] ?? $type;
}

// Validate email
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Validate phone
function isValidPhone($phone) {
    return preg_match('/^[\d\s\-\(\)\.]+$/', $phone);
}

// Generate CSRF token
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Verify CSRF token
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Flash message functions
function setFlashMessage($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlashMessage() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

// Display flash message HTML
function displayFlashMessage() {
    $flash = getFlashMessage();
    if ($flash) {
        echo "<div class='alert alert-{$flash['type']} alert-dismissible fade show'>
                {$flash['message']}
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
              </div>";
    }
}

// Simple encryption for credit card (for demo - use proper encryption in production)
function encryptData($data) {
    $key = 'your-secret-key-change-this';
    return base64_encode(openssl_encrypt($data, 'AES-256-CBC', $key, 0, substr(md5($key), 0, 16)));
}

function decryptData($data) {
    $key = 'your-secret-key-change-this';
    return openssl_decrypt(base64_decode($data), 'AES-256-CBC', $key, 0, substr(md5($key), 0, 16));
}

// Mask credit card number
function maskCreditCard($number) {
    return '****-****-****-' . substr($number, -4);
}
?>
