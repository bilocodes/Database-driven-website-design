<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? 'Anna Johnson Cleaning Services' ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="/cleaning_service/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="/cleaning_service/">
                <i class="bi bi-house-heart"></i> Anna's Cleaning
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if (isClientLoggedIn()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/cleaning_service/client/dashboard.php">
                                <i class="bi bi-speedometer2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/cleaning_service/client/new_request.php">
                                <i class="bi bi-plus-circle"></i> New Request
                            </a>
                        </li>
                        <li class="nav-item">
                            <span class="nav-link text-light">
                                <i class="bi bi-person"></i> <?= htmlspecialchars($_SESSION['client_name'] ?? 'Client') ?>
                            </span>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/cleaning_service/client/logout.php">
                                <i class="bi bi-box-arrow-right"></i> Logout
                            </a>
                        </li>
                    <?php elseif (isAdminLoggedIn()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/cleaning_service/admin/dashboard.php">
                                <i class="bi bi-speedometer2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <span class="nav-link text-light">
                                <i class="bi bi-person-badge"></i> <?= htmlspecialchars($_SESSION['admin_name'] ?? 'Admin') ?>
                            </span>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/cleaning_service/admin/logout.php">
                                <i class="bi bi-box-arrow-right"></i> Logout
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/cleaning_service/client/login.php">
                                <i class="bi bi-box-arrow-in-right"></i> Client Login
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/cleaning_service/client/register.php">
                                <i class="bi bi-person-plus"></i> Register
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/cleaning_service/admin/login.php">
                                <i class="bi bi-shield-lock"></i> Admin
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <main class="container py-4">
        <?php displayFlashMessage(); ?>
