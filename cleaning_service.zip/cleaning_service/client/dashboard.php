<?php
$pageTitle = 'Dashboard - Anna Johnson Cleaning';
require_once '../config/database.php';
require_once '../includes/header.php';
requireClientLogin();

$client_id = getClientId();

// Get client's requests
$stmt = $pdo->prepare("SELECT * FROM service_requests WHERE client_id = ? ORDER BY created_at DESC");
$stmt->execute([$client_id]);
$requests = $stmt->fetchAll();

// Get client's orders
$stmt = $pdo->prepare("
    SELECT o.*, sr.service_address, sr.cleaning_type 
    FROM orders o 
    JOIN service_requests sr ON o.request_id = sr.request_id 
    WHERE sr.client_id = ? 
    ORDER BY o.created_at DESC
");
$stmt->execute([$client_id]);
$orders = $stmt->fetchAll();

// Get pending bills
$stmt = $pdo->prepare("
    SELECT b.*, o.order_id, sr.service_address
    FROM bills b
    JOIN orders o ON b.order_id = o.order_id
    JOIN service_requests sr ON o.request_id = sr.request_id
    WHERE sr.client_id = ? AND b.status IN ('pending', 'disputed')
    ORDER BY b.created_at DESC
");
$stmt->execute([$client_id]);
$pending_bills = $stmt->fetchAll();

// Stats
$stats = [
    'total_requests' => count($requests),
    'active_requests' => count(array_filter($requests, fn($r) => in_array($r['status'], ['pending', 'negotiating']))),
    'total_orders' => count($orders),
    'pending_bills' => count($pending_bills)
];
?>

<h2><i class="bi bi-speedometer2"></i> My Dashboard</h2>
<p class="text-muted">Welcome back, <?= htmlspecialchars($_SESSION['client_name']) ?>!</p>

<!-- Stats Cards -->
<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <h3><?= $stats['total_requests'] ?></h3>
                <p class="mb-0">Total Requests</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-info text-white">
            <div class="card-body">
                <h3><?= $stats['active_requests'] ?></h3>
                <p class="mb-0">Active Requests</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-success text-white">
            <div class="card-body">
                <h3><?= $stats['total_orders'] ?></h3>
                <p class="mb-0">Total Orders</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-warning">
            <div class="card-body">
                <h3><?= $stats['pending_bills'] ?></h3>
                <p class="mb-0">Pending Bills</p>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="mb-4">
    <a href="new_request.php" class="btn btn-primary">
        <i class="bi bi-plus-circle"></i> New Service Request
    </a>
</div>

<!-- Pending Bills Alert -->
<?php if (count($pending_bills) > 0): ?>
<div class="alert alert-warning">
    <h5><i class="bi bi-exclamation-triangle"></i> Pending Bills</h5>
    <?php foreach ($pending_bills as $bill): ?>
        <div class="d-flex justify-content-between align-items-center mb-2">
            <span>
                Bill #<?= $bill['bill_id'] ?> - <?= formatMoney($bill['amount']) ?>
                (<?= htmlspecialchars($bill['service_address']) ?>)
            </span>
            <a href="view_bill.php?id=<?= $bill['bill_id'] ?>" class="btn btn-sm btn-warning">
                View & Pay
            </a>
        </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Service Requests -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0"><i class="bi bi-list-task"></i> My Service Requests</h5>
    </div>
    <div class="card-body">
        <?php if (empty($requests)): ?>
            <p class="text-muted">No service requests yet. <a href="new_request.php">Create one now!</a></p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Type</th>
                            <th>Address</th>
                            <th>Date</th>
                            <th>Budget</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($requests as $req): ?>
                        <tr>
                            <td>#<?= $req['request_id'] ?></td>
                            <td><?= getCleaningTypeName($req['cleaning_type']) ?></td>
                            <td><?= htmlspecialchars(substr($req['service_address'], 0, 30)) ?>...</td>
                            <td><?= formatDate($req['preferred_date']) ?></td>
                            <td><?= formatMoney($req['proposed_budget']) ?></td>
                            <td><?= getStatusBadge($req['status']) ?></td>
                            <td>
                                <a href="view_request.php?id=<?= $req['request_id'] ?>" class="btn btn-sm btn-outline-primary">
                                    View
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Orders -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0"><i class="bi bi-clipboard-check"></i> My Orders</h5>
    </div>
    <div class="card-body">
        <?php if (empty($orders)): ?>
            <p class="text-muted">No orders yet. Orders are created when you accept a quote.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Type</th>
                            <th>Scheduled</th>
                            <th>Price</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                        <tr>
                            <td>#<?= $order['order_id'] ?></td>
                            <td><?= getCleaningTypeName($order['cleaning_type']) ?></td>
                            <td><?= formatDate($order['scheduled_date']) ?> <?= formatTime($order['scheduled_time_start']) ?></td>
                            <td><?= formatMoney($order['final_price']) ?></td>
                            <td><?= getStatusBadge($order['status']) ?></td>
                            <td>
                                <a href="view_order.php?id=<?= $order['order_id'] ?>" class="btn btn-sm btn-outline-primary">
                                    View
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
