<?php
$pageTitle = 'View Order - Anna Johnson Cleaning';
require_once '../config/database.php';
require_once '../includes/header.php';
requireClientLogin();

$client_id = getClientId();
$order_id = (int)($_GET['id'] ?? 0);

// Get order with request info (verify ownership)
$stmt = $pdo->prepare("
    SELECT o.*, sr.*, c.first_name, c.last_name, c.email, c.phone
    FROM orders o
    JOIN service_requests sr ON o.request_id = sr.request_id
    JOIN clients c ON sr.client_id = c.client_id
    WHERE o.order_id = ? AND sr.client_id = ?
");
$stmt->execute([$order_id, $client_id]);
$order = $stmt->fetch();

if (!$order) {
    setFlashMessage('danger', 'Order not found.');
    header('Location: dashboard.php');
    exit;
}

// Get bills for this order
$stmt = $pdo->prepare("SELECT * FROM bills WHERE order_id = ? ORDER BY created_at DESC");
$stmt->execute([$order_id]);
$bills = $stmt->fetchAll();
?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Order #<?= $order_id ?></li>
    </ol>
</nav>

<div class="row">
    <div class="col-lg-8">
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="bi bi-clipboard-check"></i> Order #<?= $order_id ?></h5>
                <?= getStatusBadge($order['status']) ?>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Service Details</h6>
                        <p><strong>Type:</strong> <?= getCleaningTypeName($order['cleaning_type']) ?></p>
                        <p><strong>Rooms:</strong> <?= $order['num_rooms'] ?></p>
                        <p><strong>Address:</strong> <?= htmlspecialchars($order['service_address']) ?></p>
                    </div>
                    <div class="col-md-6">
                        <h6>Schedule</h6>
                        <p><strong>Date:</strong> <?= formatDate($order['scheduled_date']) ?></p>
                        <p><strong>Time:</strong> <?= formatTime($order['scheduled_time_start']) ?> - <?= formatTime($order['scheduled_time_end']) ?></p>
                        <p><strong>Final Price:</strong> <span class="fs-4 text-success"><?= formatMoney($order['final_price']) ?></span></p>
                    </div>
                </div>

                <?php if ($order['notes']): ?>
                    <hr>
                    <p><strong>Special Instructions:</strong> <?= nl2br(htmlspecialchars($order['notes'])) ?></p>
                <?php endif; ?>

                <hr>
                <p class="text-muted mb-0">
                    <small>Order created: <?= formatDateTime($order['created_at']) ?></small>
                    <?php if ($order['completed_at']): ?>
                        <br><small>Completed: <?= formatDateTime($order['completed_at']) ?></small>
                    <?php endif; ?>
                </p>
            </div>
        </div>

        <!-- Bills Section -->
        <?php if (!empty($bills)): ?>
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-receipt"></i> Bills</h5>
            </div>
            <div class="card-body">
                <?php foreach ($bills as $bill): ?>
                <div class="border rounded p-3 mb-3">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h5>Bill #<?= $bill['bill_id'] ?> - <?= formatMoney($bill['amount']) ?></h5>
                            <p class="text-muted mb-1"><?= htmlspecialchars($bill['description'] ?? 'Cleaning service') ?></p>
                            <small class="text-muted">Created: <?= formatDateTime($bill['created_at']) ?></small>
                        </div>
                        <div class="text-end">
                            <?= getStatusBadge($bill['status']) ?>
                            <br>
                            <a href="view_bill.php?id=<?= $bill['bill_id'] ?>" class="btn btn-sm btn-primary mt-2">
                                <?= $bill['status'] === 'pending' ? 'Pay Now' : 'View Details' ?>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php else: ?>
            <?php if ($order['status'] === 'completed'): ?>
            <div class="alert alert-info">
                <i class="bi bi-info-circle"></i> Service completed. Bill will be generated shortly.
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Order Status</h5>
            </div>
            <div class="card-body">
                <div class="status-timeline">
                    <div class="status-step <?= in_array($order['status'], ['scheduled', 'in_progress', 'completed']) ? 'completed' : '' ?>">
                        <i class="bi bi-calendar-check"></i> Scheduled
                    </div>
                    <div class="status-step <?= in_array($order['status'], ['in_progress', 'completed']) ? 'completed' : '' ?>">
                        <i class="bi bi-gear"></i> In Progress
                    </div>
                    <div class="status-step <?= $order['status'] === 'completed' ? 'completed' : '' ?>">
                        <i class="bi bi-check-circle"></i> Completed
                    </div>
                </div>
            </div>
        </div>

        <div class="card mt-3">
            <div class="card-header">
                <h5 class="mb-0">Need Help?</h5>
            </div>
            <div class="card-body">
                <p><i class="bi bi-envelope"></i> contact@annacleaning.com</p>
                <p class="mb-0"><i class="bi bi-telephone"></i> (555) 123-4567</p>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
