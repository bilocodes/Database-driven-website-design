<?php
$pageTitle = 'Client Login - Anna Johnson Cleaning';
require_once '../config/database.php';
require_once '../includes/header.php';

// Redirect if already logged in
if (isClientLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Please enter email and password';
    } else {
        $stmt = $pdo->prepare("SELECT client_id, first_name, last_name, password_hash FROM clients WHERE email = ?");
        $stmt->execute([$email]);
        $client = $stmt->fetch();

        if ($client && password_verify($password, $client['password_hash'])) {
            $_SESSION['client_id'] = $client['client_id'];
            $_SESSION['client_name'] = $client['first_name'] . ' ' . $client['last_name'];
            
            setFlashMessage('success', 'Welcome back, ' . $client['first_name'] . '!');
            header('Location: dashboard.php');
            exit;
        } else {
            $error = 'Invalid email or password';
        }
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-5 col-lg-4">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0"><i class="bi bi-box-arrow-in-right"></i> Client Login</h4>
            </div>
            <div class="card-body">
                
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" 
                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required autofocus>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-box-arrow-in-right"></i> Login
                        </button>
                    </div>
                </form>

                <hr>
                <p class="text-center mb-0">
                    Don't have an account? <a href="register.php">Register here</a>
                </p>
            </div>
        </div>

        <div class="card mt-3">
            <div class="card-body text-center">
                <small class="text-muted">
                    Test Account: john@example.com / client123
                </small>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
