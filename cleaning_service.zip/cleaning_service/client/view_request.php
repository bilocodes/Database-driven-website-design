<?php
$pageTitle = 'View Request - Anna Johnson Cleaning';
require_once '../config/database.php';
require_once '../includes/header.php';
requireClientLogin();

$client_id = getClientId();
$request_id = (int)($_GET['id'] ?? 0);

// Get request (verify ownership)
$stmt = $pdo->prepare("SELECT * FROM service_requests WHERE request_id = ? AND client_id = ?");
$stmt->execute([$request_id, $client_id]);
$request = $stmt->fetch();

if (!$request) {
    setFlashMessage('danger', 'Request not found.');
    header('Location: dashboard.php');
    exit;
}

// Get photos
$stmt = $pdo->prepare("SELECT * FROM request_photos WHERE request_id = ?");
$stmt->execute([$request_id]);
$photos = $stmt->fetchAll();

// Get quote responses (conversation history)
$stmt = $pdo->prepare("SELECT * FROM quote_responses WHERE request_id = ? ORDER BY created_at ASC");
$stmt->execute([$request_id]);
$responses = $stmt->fetchAll();

// Get latest Anna quote
$stmt = $pdo->prepare("
    SELECT * FROM quote_responses 
    WHERE request_id = ? AND responder = 'anna' AND response_type = 'quote' 
    ORDER BY created_at DESC LIMIT 1
");
$stmt->execute([$request_id]);
$latest_quote = $stmt->fetch();

// Handle form submissions
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'accept' && $latest_quote) {
        // Accept quote → Create order
        try {
            $pdo->beginTransaction();

            // Record acceptance
            $stmt = $pdo->prepare("INSERT INTO quote_responses (request_id, responder, response_type, note) VALUES (?, 'client', 'accept', 'Quote accepted')");
            $stmt->execute([$request_id]);

            // Create order
            $stmt = $pdo->prepare("INSERT INTO orders (request_id, final_price, scheduled_date, scheduled_time_start, scheduled_time_end) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([
                $request_id,
                $latest_quote['adjusted_price'],
                $latest_quote['scheduled_date'],
                $latest_quote['scheduled_time_start'],
                $latest_quote['scheduled_time_end']
            ]);

            // Update request status
            $stmt = $pdo->prepare("UPDATE service_requests SET status = 'accepted' WHERE request_id = ?");
            $stmt->execute([$request_id]);

            $pdo->commit();

            setFlashMessage('success', 'Quote accepted! Your order has been created.');
            header('Location: dashboard.php');
            exit;

        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = "Failed to accept quote. Please try again.";
        }

    } elseif ($action === 'counter') {
        $note = sanitize($_POST['note'] ?? '');
        if (empty($note)) {
            $errors[] = "Please provide a note for your counter-offer.";
        } else {
            $stmt = $pdo->prepare("INSERT INTO quote_responses (request_id, responder, response_type, note) VALUES (?, 'client', 'counter', ?)");
            $stmt->execute([$request_id, $note]);

            $stmt = $pdo->prepare("UPDATE service_requests SET status = 'negotiating' WHERE request_id = ?");
            $stmt->execute([$request_id]);

            setFlashMessage('success', 'Counter-offer submitted.');
            header('Location: view_request.php?id=' . $request_id);
            exit;
        }

    } elseif ($action === 'cancel') {
        $stmt = $pdo->prepare("INSERT INTO quote_responses (request_id, responder, response_type, note) VALUES (?, 'client', 'cancel', 'Request canceled by client')");
        $stmt->execute([$request_id]);

        $stmt = $pdo->prepare("UPDATE service_requests SET status = 'canceled' WHERE request_id = ?");
        $stmt->execute([$request_id]);

        setFlashMessage('info', 'Request has been canceled.');
        header('Location: dashboard.php');
        exit;
    }

    // Refresh data
    header('Location: view_request.php?id=' . $request_id);
    exit;
}
?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Request #<?= $request_id ?></li>
    </ol>
</nav>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php foreach ($errors as $error): ?>
                <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="row">
    <!-- Request Details -->
    <div class="col-lg-8">
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="bi bi-file-text"></i> Request #<?= $request_id ?></h5>
                <?= getStatusBadge($request['status']) ?>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Type:</strong> <?= getCleaningTypeName($request['cleaning_type']) ?></p>
                        <p><strong>Rooms:</strong> <?= $request['num_rooms'] ?></p>
                        <p><strong>Proposed Budget:</strong> <?= formatMoney($request['proposed_budget']) ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Preferred Date:</strong> <?= formatDate($request['preferred_date']) ?></p>
                        <p><strong>Preferred Time:</strong> <?= formatTime($request['preferred_time']) ?></p>
                        <p><strong>Submitted:</strong> <?= formatDateTime($request['created_at']) ?></p>
                    </div>
                </div>
                <p><strong>Address:</strong> <?= htmlspecialchars($request['service_address']) ?></p>
                <?php if ($request['notes']): ?>
                    <p><strong>Notes:</strong> <?= nl2br(htmlspecialchars($request['notes'])) ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Photos -->
        <?php if (!empty($photos)): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-images"></i> Photos</h5>
            </div>
            <div class="card-body">
                <div class="row g-2">
                    <?php foreach ($photos as $photo): ?>
                    <div class="col-4 col-md-3">
                        <a href="../uploads/photos/<?= htmlspecialchars($photo['file_path']) ?>" target="_blank">
                            <img src="../uploads/photos/<?= htmlspecialchars($photo['file_path']) ?>" 
                                 class="img-fluid rounded" alt="Request photo">
                        </a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Conversation History -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-chat-dots"></i> Quote & Negotiation History</h5>
            </div>
            <div class="card-body">
                <?php if (empty($responses)): ?>
                    <p class="text-muted">Waiting for Anna to respond with a quote...</p>
                <?php else: ?>
                    <div class="timeline">
                        <?php foreach ($responses as $resp): ?>
                        <div class="timeline-item <?= $resp['responder'] === 'anna' ? 'anna' : 'client' ?>">
                            <div class="timeline-badge">
                                <i class="bi bi-<?= $resp['responder'] === 'anna' ? 'person-badge' : 'person' ?>"></i>
                            </div>
                            <div class="timeline-content">
                                <div class="d-flex justify-content-between">
                                    <strong><?= $resp['responder'] === 'anna' ? 'Anna' : 'You' ?></strong>
                                    <small class="text-muted"><?= formatDateTime($resp['created_at']) ?></small>
                                </div>
                                
                                <?php if ($resp['response_type'] === 'quote'): ?>
                                    <div class="alert alert-info mt-2 mb-0">
                                        <strong>Quote:</strong> <?= formatMoney($resp['adjusted_price']) ?><br>
                                        <strong>Schedule:</strong> <?= formatDate($resp['scheduled_date']) ?> 
                                        <?= formatTime($resp['scheduled_time_start']) ?> - <?= formatTime($resp['scheduled_time_end']) ?>
                                        <?php if ($resp['note']): ?>
                                            <br><strong>Note:</strong> <?= htmlspecialchars($resp['note']) ?>
                                        <?php endif; ?>
                                    </div>
                                <?php elseif ($resp['response_type'] === 'rejection'): ?>
                                    <div class="alert alert-danger mt-2 mb-0">
                                        <strong>Rejected:</strong> <?= htmlspecialchars($resp['note']) ?>
                                    </div>
                                <?php elseif ($resp['response_type'] === 'accept'): ?>
                                    <div class="alert alert-success mt-2 mb-0">
                                        <strong>Quote Accepted!</strong>
                                    </div>
                                <?php elseif ($resp['response_type'] === 'cancel'): ?>
                                    <div class="alert alert-secondary mt-2 mb-0">
                                        <strong>Canceled</strong>
                                    </div>
                                <?php else: ?>
                                    <p class="mt-2 mb-0"><?= htmlspecialchars($resp['note']) ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Actions Sidebar -->
    <div class="col-lg-4">
        <?php if ($request['status'] === 'negotiating' && $latest_quote): ?>
        <div class="card mb-3">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="bi bi-check-circle"></i> Latest Quote</h5>
            </div>
            <div class="card-body">
                <h3 class="text-success"><?= formatMoney($latest_quote['adjusted_price']) ?></h3>
                <p class="mb-1"><strong>Date:</strong> <?= formatDate($latest_quote['scheduled_date']) ?></p>
                <p class="mb-3"><strong>Time:</strong> <?= formatTime($latest_quote['scheduled_time_start']) ?> - <?= formatTime($latest_quote['scheduled_time_end']) ?></p>
                
                <form method="POST" action="">
                    <input type="hidden" name="action" value="accept">
                    <button type="submit" class="btn btn-success btn-lg w-100 mb-2">
                        <i class="bi bi-check-lg"></i> Accept Quote
                    </button>
                </form>

                <button class="btn btn-outline-warning w-100" type="button" data-bs-toggle="collapse" data-bs-target="#counterForm">
                    <i class="bi bi-arrow-repeat"></i> Counter-Offer
                </button>

                <div class="collapse mt-3" id="counterForm">
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="counter">
                        <textarea name="note" class="form-control mb-2" rows="3" 
                                  placeholder="e.g., 'Too expensive, can you do $150?' or 'Need afternoon instead'"></textarea>
                        <button type="submit" class="btn btn-warning w-100">Submit Counter-Offer</button>
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if (in_array($request['status'], ['pending', 'negotiating'])): ?>
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Actions</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="" onsubmit="return confirm('Are you sure you want to cancel this request?');">
                    <input type="hidden" name="action" value="cancel">
                    <button type="submit" class="btn btn-outline-danger w-100">
                        <i class="bi bi-x-circle"></i> Cancel Request
                    </button>
                </form>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($request['status'] === 'accepted'): ?>
        <div class="alert alert-success">
            <h5><i class="bi bi-check-circle"></i> Order Created</h5>
            <p>This request has been converted to an order.</p>
            <a href="dashboard.php" class="btn btn-success">View Orders</a>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
