<?php
$pageTitle = 'View Bill - Anna Johnson Cleaning';
require_once '../config/database.php';
require_once '../includes/header.php';
requireClientLogin();

$client_id = getClientId();
$bill_id = (int)($_GET['id'] ?? 0);

// Get bill with order and client info (verify ownership)
$stmt = $pdo->prepare("
    SELECT b.*, o.*, sr.service_address, sr.cleaning_type, sr.num_rooms,
           c.first_name, c.last_name, c.cc_number_encrypted
    FROM bills b
    JOIN orders o ON b.order_id = o.order_id
    JOIN service_requests sr ON o.request_id = sr.request_id
    JOIN clients c ON sr.client_id = c.client_id
    WHERE b.bill_id = ? AND sr.client_id = ?
");
$stmt->execute([$bill_id, $client_id]);
$bill = $stmt->fetch();

if (!$bill) {
    setFlashMessage('danger', 'Bill not found.');
    header('Location: dashboard.php');
    exit;
}

// Get bill responses (dispute history)
$stmt = $pdo->prepare("SELECT * FROM bill_responses WHERE bill_id = ? ORDER BY created_at ASC");
$stmt->execute([$bill_id]);
$responses = $stmt->fetchAll();

// Get latest bill amount (could be revised)
$current_amount = $bill['amount'];
foreach ($responses as $resp) {
    if ($resp['revised_amount']) {
        $current_amount = $resp['revised_amount'];
    }
}

$errors = [];

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'pay') {
        // Process payment (simulated)
        try {
            $pdo->beginTransaction();

            // Record payment
            $stmt = $pdo->prepare("INSERT INTO bill_responses (bill_id, responder, response_type, note) VALUES (?, 'client', 'payment', 'Payment processed')");
            $stmt->execute([$bill_id]);

            // Update bill status
            $stmt = $pdo->prepare("UPDATE bills SET status = 'paid', paid_at = NOW() WHERE bill_id = ?");
            $stmt->execute([$bill_id]);

            $pdo->commit();

            setFlashMessage('success', 'Payment successful! Thank you.');
            header('Location: dashboard.php');
            exit;

        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = "Payment failed. Please try again.";
        }

    } elseif ($action === 'dispute') {
        $note = sanitize($_POST['note'] ?? '');
        if (empty($note)) {
            $errors[] = "Please explain the reason for your dispute.";
        } else {
            $stmt = $pdo->prepare("INSERT INTO bill_responses (bill_id, responder, response_type, note) VALUES (?, 'client', 'dispute', ?)");
            $stmt->execute([$bill_id, $note]);

            $stmt = $pdo->prepare("UPDATE bills SET status = 'disputed' WHERE bill_id = ?");
            $stmt->execute([$bill_id]);

            setFlashMessage('warning', 'Dispute submitted. Anna will review and respond.');
            header('Location: view_bill.php?id=' . $bill_id);
            exit;
        }
    }
}

// Mask credit card
$cc_last4 = '****';
if ($bill['cc_number_encrypted']) {
    $cc_decrypted = decryptData($bill['cc_number_encrypted']);
    if ($cc_decrypted) {
        $cc_last4 = substr($cc_decrypted, -4);
    }
}
?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="view_order.php?id=<?= $bill['order_id'] ?>">Order #<?= $bill['order_id'] ?></a></li>
        <li class="breadcrumb-item active">Bill #<?= $bill_id ?></li>
    </ol>
</nav>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php foreach ($errors as $error): ?>
                <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-lg-8">
        <!-- Bill Details -->
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="bi bi-receipt"></i> Bill #<?= $bill_id ?></h5>
                <?= getStatusBadge($bill['status']) ?>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Service Details</h6>
                        <p><strong>Order:</strong> #<?= $bill['order_id'] ?></p>
                        <p><strong>Type:</strong> <?= getCleaningTypeName($bill['cleaning_type']) ?></p>
                        <p><strong>Address:</strong> <?= htmlspecialchars($bill['service_address']) ?></p>
                        <p><strong>Date:</strong> <?= formatDate($bill['scheduled_date']) ?></p>
                    </div>
                    <div class="col-md-6">
                        <h6>Billing</h6>
                        <p><strong>Original Amount:</strong> <?= formatMoney($bill['amount']) ?></p>
                        <?php if ($current_amount != $bill['amount']): ?>
                            <p><strong>Revised Amount:</strong> <span class="text-success"><?= formatMoney($current_amount) ?></span></p>
                        <?php endif; ?>
                        <p><strong>Created:</strong> <?= formatDateTime($bill['created_at']) ?></p>
                        <?php if ($bill['paid_at']): ?>
                            <p><strong>Paid:</strong> <?= formatDateTime($bill['paid_at']) ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if ($bill['description']): ?>
                    <hr>
                    <p><strong>Description:</strong> <?= nl2br(htmlspecialchars($bill['description'])) ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Dispute History -->
        <?php if (!empty($responses)): ?>
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-chat-dots"></i> Billing History</h5>
            </div>
            <div class="card-body">
                <div class="timeline">
                    <?php foreach ($responses as $resp): ?>
                    <div class="timeline-item <?= $resp['responder'] === 'anna' ? 'anna' : 'client' ?>">
                        <div class="timeline-badge">
                            <i class="bi bi-<?= $resp['responder'] === 'anna' ? 'person-badge' : 'person' ?>"></i>
                        </div>
                        <div class="timeline-content">
                            <div class="d-flex justify-content-between">
                                <strong><?= $resp['responder'] === 'anna' ? 'Anna' : 'You' ?></strong>
                                <small class="text-muted"><?= formatDateTime($resp['created_at']) ?></small>
                            </div>
                            
                            <?php if ($resp['response_type'] === 'revision'): ?>
                                <div class="alert alert-info mt-2 mb-0">
                                    <strong>Revised Amount:</strong> <?= formatMoney($resp['revised_amount']) ?>
                                    <?php if ($resp['note']): ?>
                                        <br><?= htmlspecialchars($resp['note']) ?>
                                    <?php endif; ?>
                                </div>
                            <?php elseif ($resp['response_type'] === 'payment'): ?>
                                <div class="alert alert-success mt-2 mb-0">
                                    <strong>Payment Received</strong>
                                </div>
                            <?php else: ?>
                                <p class="mt-2 mb-0"><?= htmlspecialchars($resp['note']) ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Payment Sidebar -->
    <div class="col-lg-4">
        <?php if ($bill['status'] !== 'paid'): ?>
        <div class="card mb-3">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="bi bi-credit-card"></i> Pay Now</h5>
            </div>
            <div class="card-body">
                <h2 class="text-center text-success mb-3"><?= formatMoney($current_amount) ?></h2>
                
                <p class="text-center text-muted">
                    <i class="bi bi-credit-card"></i> Card ending in <?= $cc_last4 ?>
                </p>

                <form method="POST" action="" onsubmit="return confirm('Process payment of <?= formatMoney($current_amount) ?>?');">
                    <input type="hidden" name="action" value="pay">
                    <button type="submit" class="btn btn-success btn-lg w-100">
                        <i class="bi bi-check-circle"></i> Pay <?= formatMoney($current_amount) ?>
                    </button>
                </form>

                <?php if ($bill['status'] !== 'disputed'): ?>
                <hr>
                <button class="btn btn-outline-warning w-100" type="button" data-bs-toggle="collapse" data-bs-target="#disputeForm">
                    <i class="bi bi-exclamation-triangle"></i> Dispute Bill
                </button>

                <div class="collapse mt-3" id="disputeForm">
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="dispute">
                        <textarea name="note" class="form-control mb-2" rows="3" 
                                  placeholder="Explain why you're disputing this bill..."></textarea>
                        <button type="submit" class="btn btn-warning w-100">Submit Dispute</button>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php else: ?>
        <div class="alert alert-success">
            <h5><i class="bi bi-check-circle"></i> Paid</h5>
            <p class="mb-0">This bill was paid on <?= formatDateTime($bill['paid_at']) ?></p>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Questions?</h5>
            </div>
            <div class="card-body">
                <p>If you have questions about this bill, please contact us:</p>
                <p><i class="bi bi-envelope"></i> contact@annacleaning.com</p>
                <p class="mb-0"><i class="bi bi-telephone"></i> (555) 123-4567</p>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
