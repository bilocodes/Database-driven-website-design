<?php
$pageTitle = 'Register - Anna Johnson Cleaning';
require_once '../config/database.php';
require_once '../includes/header.php';

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get and sanitize inputs
    $first_name = sanitize($_POST['first_name'] ?? '');
    $last_name = sanitize($_POST['last_name'] ?? '');
    $address = sanitize($_POST['address'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $cc_number = sanitize($_POST['cc_number'] ?? '');
    $cc_expiry = sanitize($_POST['cc_expiry'] ?? '');
    $cc_cvv = sanitize($_POST['cc_cvv'] ?? '');

    // Validation
    if (empty($first_name)) $errors[] = "First name is required";
    if (empty($last_name)) $errors[] = "Last name is required";
    if (empty($address)) $errors[] = "Address is required";
    if (empty($phone)) $errors[] = "Phone number is required";
    if (!isValidPhone($phone)) $errors[] = "Invalid phone number format";
    if (empty($email)) $errors[] = "Email is required";
    if (!isValidEmail($email)) $errors[] = "Invalid email format";
    if (strlen($password) < 6) $errors[] = "Password must be at least 6 characters";
    if ($password !== $confirm_password) $errors[] = "Passwords do not match";
    if (empty($cc_number) || strlen(preg_replace('/\D/', '', $cc_number)) < 13) $errors[] = "Valid credit card number required";
    if (empty($cc_expiry)) $errors[] = "Credit card expiry required";
    if (empty($cc_cvv) || strlen($cc_cvv) < 3) $errors[] = "Valid CVV required";

    // Check email exists
    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT client_id FROM clients WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = "Email already registered";
        }
    }

    // Insert if no errors
    if (empty($errors)) {
        try {
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $cc_encrypted = encryptData(preg_replace('/\D/', '', $cc_number));
            $cvv_encrypted = encryptData($cc_cvv);

            $stmt = $pdo->prepare("INSERT INTO clients 
                (first_name, last_name, address, phone, email, password_hash, cc_number_encrypted, cc_expiry, cc_cvv_encrypted) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            $stmt->execute([
                $first_name, $last_name, $address, $phone, $email,
                $password_hash, $cc_encrypted, $cc_expiry, $cvv_encrypted
            ]);

            $success = true;
            setFlashMessage('success', 'Registration successful! Please login.');
            header('Location: login.php');
            exit;

        } catch (PDOException $e) {
            $errors[] = "Registration failed. Please try again.";
        }
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0"><i class="bi bi-person-plus"></i> Client Registration</h4>
            </div>
            <div class="card-body">
                
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?= htmlspecialchars($error) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <h5 class="border-bottom pb-2 mb-3">Personal Information</h5>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">First Name *</label>
                            <input type="text" name="first_name" class="form-control" 
                                   value="<?= htmlspecialchars($first_name ?? '') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Last Name *</label>
                            <input type="text" name="last_name" class="form-control" 
                                   value="<?= htmlspecialchars($last_name ?? '') ?>" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Address *</label>
                        <input type="text" name="address" class="form-control" 
                               value="<?= htmlspecialchars($address ?? '') ?>" required>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Phone *</label>
                            <input type="tel" name="phone" class="form-control" 
                                   value="<?= htmlspecialchars($phone ?? '') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email *</label>
                            <input type="email" name="email" class="form-control" 
                                   value="<?= htmlspecialchars($email ?? '') ?>" required>
                        </div>
                    </div>

                    <h5 class="border-bottom pb-2 mb-3 mt-4">Account Security</h5>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Password *</label>
                            <input type="password" name="password" class="form-control" 
                                   minlength="6" required>
                            <small class="text-muted">Minimum 6 characters</small>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Confirm Password *</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                    </div>

                    <h5 class="border-bottom pb-2 mb-3 mt-4">Payment Information</h5>

                    <div class="mb-3">
                        <label class="form-label">Credit Card Number *</label>
                        <input type="text" name="cc_number" class="form-control" 
                               placeholder="1234 5678 9012 3456" required>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Expiry Date *</label>
                            <input type="text" name="cc_expiry" class="form-control" 
                                   placeholder="MM/YY" maxlength="5" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">CVV *</label>
                            <input type="text" name="cc_cvv" class="form-control" 
                                   placeholder="123" maxlength="4" required>
                        </div>
                    </div>

                    <div class="d-grid gap-2 mt-4">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="bi bi-check-circle"></i> Register
                        </button>
                    </div>
                </form>

                <hr>
                <p class="text-center mb-0">
                    Already have an account? <a href="login.php">Login here</a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
