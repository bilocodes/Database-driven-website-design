<?php
$pageTitle = 'New Service Request - Anna Johnson Cleaning';
require_once '../config/database.php';
require_once '../includes/header.php';
requireClientLogin();

$errors = [];
$client_id = getClientId();

// Validate client_id exists in database
if (empty($client_id)) {
    $errors[] = "Session expired. Please login again.";
} else {
    $stmt = $pdo->prepare("SELECT client_id FROM clients WHERE client_id = ?");
    $stmt->execute([$client_id]);
    if (!$stmt->fetch()) {
        $errors[] = "Invalid client session. Please login again.";
        $client_id = null;
    }
}

// Get client's default address
$stmt = $pdo->prepare("SELECT address FROM clients WHERE client_id = ?");
$stmt->execute([$client_id]);
$client = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $client_id) {
    // Sanitize inputs
    $service_address = sanitize($_POST['service_address'] ?? '');
    $cleaning_type = sanitize($_POST['cleaning_type'] ?? '');
    $num_rooms = (int)($_POST['num_rooms'] ?? 0);
    $preferred_date = sanitize($_POST['preferred_date'] ?? '');
    $preferred_time = sanitize($_POST['preferred_time'] ?? '');
    $proposed_budget = (float)($_POST['proposed_budget'] ?? 0);
    $notes = sanitize($_POST['notes'] ?? '');

    // Validation
    if (empty($service_address)) $errors[] = "Service address is required";
    if (strlen($service_address) > 255) $errors[] = "Service address is too long (max 255 characters)";
    if (!in_array($cleaning_type, ['basic', 'deep_cleaning', 'move_out'])) $errors[] = "Invalid cleaning type";
    if ($num_rooms < 1 || $num_rooms > 50) $errors[] = "Number of rooms must be between 1 and 50";
    if (empty($preferred_date)) $errors[] = "Preferred date is required";
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $preferred_date)) $errors[] = "Invalid date format";
    if (strtotime($preferred_date) < strtotime('today')) $errors[] = "Date must be today or later";
    if (empty($preferred_time)) $errors[] = "Preferred time is required";
    if (!preg_match('/^\d{2}:\d{2}$/', $preferred_time)) $errors[] = "Invalid time format";
    if ($proposed_budget < 1 || $proposed_budget > 100000) $errors[] = "Budget must be between $1 and $100,000";

    // Photo validation
    $max_photos = 5;
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $max_size = 5 * 1024 * 1024; // 5MB

    $photos_to_upload = [];
    if (!empty($_FILES['photos']['name'][0])) {
        if (count($_FILES['photos']['name']) > $max_photos) {
            $errors[] = "Maximum $max_photos photos allowed";
        } else {
            foreach ($_FILES['photos']['tmp_name'] as $key => $tmp_name) {
                if ($_FILES['photos']['error'][$key] === UPLOAD_ERR_OK) {
                    $file_type = $_FILES['photos']['type'][$key];
                    $file_size = $_FILES['photos']['size'][$key];
                    
                    if (!in_array($file_type, $allowed_types)) {
                        $errors[] = "Invalid file type. Only JPEG, PNG, GIF, WEBP allowed.";
                        break;
                    }
                    if ($file_size > $max_size) {
                        $errors[] = "File too large. Maximum 5MB per photo.";
                        break;
                    }
                    $photos_to_upload[] = $key;
                }
            }
        }
    }

    // Insert if no errors
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            // Insert service request
            $stmt = $pdo->prepare("INSERT INTO service_requests 
                (client_id, service_address, cleaning_type, num_rooms, preferred_date, preferred_time, proposed_budget, notes) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $client_id, $service_address, $cleaning_type, $num_rooms,
                $preferred_date, $preferred_time, $proposed_budget, $notes
            ]);
            
            $request_id = $pdo->lastInsertId();

            // Upload photos
            $upload_dir = '../uploads/photos/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }

            foreach ($photos_to_upload as $key) {
                $tmp_name = $_FILES['photos']['tmp_name'][$key];
                $extension = pathinfo($_FILES['photos']['name'][$key], PATHINFO_EXTENSION);
                $filename = $request_id . '_' . time() . '_' . $key . '.' . $extension;
                
                if (move_uploaded_file($tmp_name, $upload_dir . $filename)) {
                    $stmt = $pdo->prepare("INSERT INTO request_photos (request_id, file_path) VALUES (?, ?)");
                    $stmt->execute([$request_id, $filename]);
                }
            }

            $pdo->commit();

            setFlashMessage('success', 'Service request submitted successfully! We will respond with a quote soon.');
            header('Location: view_request.php?id=' . $request_id);
            exit;

        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = "Failed to submit request. Error: " . $e->getMessage();
        }
    }
}
?>

<div class="row">
    <div class="col-lg-8">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0"><i class="bi bi-plus-circle"></i> New Service Request</h4>
            </div>
            <div class="card-body">

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?= htmlspecialchars($error) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="" enctype="multipart/form-data">
                    
                    <!-- Service Details -->
                    <h5 class="border-bottom pb-2 mb-3">Service Details</h5>

                    <div class="mb-3">
                        <label class="form-label">Service Address *</label>
                        <input type="text" name="service_address" class="form-control" 
                               value="<?= htmlspecialchars($_POST['service_address'] ?? $client['address'] ?? '') ?>" required>
                        <small class="text-muted">Address where cleaning will be performed</small>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Type of Cleaning *</label>
                            <select name="cleaning_type" class="form-select" required>
                                <option value="">Select type...</option>
                                <option value="basic" <?= ($_POST['cleaning_type'] ?? '') === 'basic' ? 'selected' : '' ?>>
                                    Basic Cleaning
                                </option>
                                <option value="deep_cleaning" <?= ($_POST['cleaning_type'] ?? '') === 'deep_cleaning' ? 'selected' : '' ?>>
                                    Deep Cleaning
                                </option>
                                <option value="move_out" <?= ($_POST['cleaning_type'] ?? '') === 'move_out' ? 'selected' : '' ?>>
                                    Move-Out Cleaning
                                </option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Number of Rooms *</label>
                            <input type="number" name="num_rooms" class="form-control" min="1" max="20"
                                   value="<?= htmlspecialchars($_POST['num_rooms'] ?? '3') ?>" required>
                        </div>
                    </div>

                    <!-- Schedule -->
                    <h5 class="border-bottom pb-2 mb-3 mt-4">Preferred Schedule</h5>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Preferred Date *</label>
                            <input type="date" name="preferred_date" class="form-control" 
                                   min="<?= date('Y-m-d') ?>"
                                   value="<?= htmlspecialchars($_POST['preferred_date'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Preferred Time *</label>
                            <input type="time" name="preferred_time" class="form-control" 
                                   value="<?= htmlspecialchars($_POST['preferred_time'] ?? '09:00') ?>" required>
                        </div>
                    </div>

                    <!-- Budget -->
                    <h5 class="border-bottom pb-2 mb-3 mt-4">Budget</h5>

                    <div class="mb-3">
                        <label class="form-label">Proposed Budget ($) *</label>
                        <div class="input-group">
                            <span class="input-group-text">$</span>
                            <input type="number" name="proposed_budget" class="form-control" 
                                   min="1" step="0.01"
                                   value="<?= htmlspecialchars($_POST['proposed_budget'] ?? '100') ?>" required>
                        </div>
                        <small class="text-muted">Your proposed budget. Anna may adjust in her quote.</small>
                    </div>

                    <!-- Notes -->
                    <h5 class="border-bottom pb-2 mb-3 mt-4">Additional Information</h5>

                    <div class="mb-3">
                        <label class="form-label">Special Instructions (Optional)</label>
                        <textarea name="notes" class="form-control" rows="3" 
                                  placeholder="e.g., Pet-friendly products only, focus on kitchen, etc."><?= htmlspecialchars($_POST['notes'] ?? '') ?></textarea>
                    </div>

                    <!-- Photos -->
                    <h5 class="border-bottom pb-2 mb-3 mt-4">Photos (Optional)</h5>

                    <div class="mb-3">
                        <label class="form-label">Upload Photos of Your Home</label>
                        <input type="file" name="photos[]" class="form-control" 
                               accept="image/jpeg,image/png,image/gif,image/webp" multiple>
                        <small class="text-muted">Maximum 5 photos, 5MB each. JPEG, PNG, GIF, WEBP only.</small>
                    </div>

                    <div class="d-grid gap-2 mt-4">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="bi bi-send"></i> Submit Request
                        </button>
                        <a href="dashboard.php" class="btn btn-outline-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Sidebar -->
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-info-circle"></i> Pricing Guide</h5>
            </div>
            <div class="card-body">
                <h6>Basic Cleaning</h6>
                <p class="small text-muted">$80-150 • Dusting, vacuuming, mopping, bathroom cleaning</p>
                
                <h6>Deep Cleaning</h6>
                <p class="small text-muted">$150-300 • Everything in basic + appliances, baseboards, inside cabinets</p>
                
                <h6>Move-Out Cleaning</h6>
                <p class="small text-muted">$200-400 • Comprehensive cleaning for full deposit return</p>

                <hr>
                <p class="small mb-0">
                    <i class="bi bi-lightbulb"></i> Prices vary by home size and condition. 
                    Anna will provide a personalized quote.
                </p>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
