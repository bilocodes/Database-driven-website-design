/**
 * Home Cleaning Service - Main JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    
    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Format credit card input
    const ccInput = document.querySelector('input[name="cc_number"]');
    if (ccInput) {
        ccInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            value = value.replace(/(.{4})/g, '$1 ').trim();
            e.target.value = value.substring(0, 19);
        });
    }

    // Format expiry date input
    const expiryInput = document.querySelector('input[name="cc_expiry"]');
    if (expiryInput) {
        expiryInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length >= 2) {
                value = value.substring(0, 2) + '/' + value.substring(2, 4);
            }
            e.target.value = value;
        });
    }

    // Phone number formatting
    const phoneInput = document.querySelector('input[name="phone"]');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length >= 6) {
                value = '(' + value.substring(0, 3) + ') ' + value.substring(3, 6) + '-' + value.substring(6, 10);
            } else if (value.length >= 3) {
                value = '(' + value.substring(0, 3) + ') ' + value.substring(3);
            }
            e.target.value = value;
        });
    }

    // Photo preview before upload
    const photoInput = document.querySelector('input[name="photos[]"]');
    if (photoInput) {
        photoInput.addEventListener('change', function(e) {
            const files = e.target.files;
            if (files.length > 5) {
                alert('Maximum 5 photos allowed!');
                e.target.value = '';
                return;
            }

            // Could add preview functionality here
        });
    }

    // Confirm dialogs for dangerous actions
    const dangerButtons = document.querySelectorAll('[data-confirm]');
    dangerButtons.forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            if (!confirm(btn.dataset.confirm)) {
                e.preventDefault();
            }
        });
    });

    // Calculate end time from start time (3 hours default)
    const startTimeInput = document.querySelector('input[name="scheduled_time_start"]');
    const endTimeInput = document.querySelector('input[name="scheduled_time_end"]');
    if (startTimeInput && endTimeInput) {
        startTimeInput.addEventListener('change', function() {
            const start = this.value;
            if (start) {
                const [hours, minutes] = start.split(':').map(Number);
                const endHours = (hours + 3) % 24;
                endTimeInput.value = 
                    String(endHours).padStart(2, '0') + ':' + 
                    String(minutes).padStart(2, '0');
            }
        });
    }

    // Budget suggestion based on cleaning type
    const cleaningTypeSelect = document.querySelector('select[name="cleaning_type"]');
    const budgetInput = document.querySelector('input[name="proposed_budget"]');
    const roomsInput = document.querySelector('input[name="num_rooms"]');
    
    if (cleaningTypeSelect && budgetInput) {
        function updateBudgetSuggestion() {
            const type = cleaningTypeSelect.value;
            const rooms = parseInt(roomsInput?.value) || 3;
            
            let basePrice = 0;
            switch(type) {
                case 'basic':
                    basePrice = 80 + (rooms * 15);
                    break;
                case 'deep_cleaning':
                    basePrice = 150 + (rooms * 25);
                    break;
                case 'move_out':
                    basePrice = 200 + (rooms * 30);
                    break;
            }
            
            if (basePrice > 0 && !budgetInput.dataset.userEdited) {
                budgetInput.value = basePrice;
            }
        }

        cleaningTypeSelect.addEventListener('change', updateBudgetSuggestion);
        if (roomsInput) {
            roomsInput.addEventListener('change', updateBudgetSuggestion);
        }
        
        budgetInput.addEventListener('input', function() {
            this.dataset.userEdited = 'true';
        });
    }

    // Print bill functionality
    const printBillBtn = document.querySelector('#printBill');
    if (printBillBtn) {
        printBillBtn.addEventListener('click', function() {
            window.print();
        });
    }
});
