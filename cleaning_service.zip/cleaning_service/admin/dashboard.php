<?php
$pageTitle = 'Admin Dashboard - Anna Johnson Cleaning';
require_once '../config/database.php';
require_once '../includes/header.php';
requireAdminLogin();

// Get pending requests
$stmt = $pdo->query("
    SELECT sr.*, c.first_name, c.last_name, c.email, c.phone
    FROM service_requests sr
    JOIN clients c ON sr.client_id = c.client_id
    WHERE sr.status IN ('pending', 'negotiating')
    ORDER BY sr.created_at DESC
");
$pending_requests = $stmt->fetchAll();

// Get active orders
$stmt = $pdo->query("
    SELECT o.*, sr.service_address, sr.cleaning_type, c.first_name, c.last_name
    FROM orders o
    JOIN service_requests sr ON o.request_id = sr.request_id
    JOIN clients c ON sr.client_id = c.client_id
    WHERE o.status IN ('scheduled', 'in_progress')
    ORDER BY o.scheduled_date ASC
");
$active_orders = $stmt->fetchAll();

// Get unpaid/disputed bills
$stmt = $pdo->query("
    SELECT b.*, o.order_id, sr.service_address, c.first_name, c.last_name
    FROM bills b
    JOIN orders o ON b.order_id = o.order_id
    JOIN service_requests sr ON o.request_id = sr.request_id
    JOIN clients c ON sr.client_id = c.client_id
    WHERE b.status IN ('pending', 'disputed')
    ORDER BY b.created_at DESC
");
$pending_bills = $stmt->fetchAll();

// Stats
$stats = [];
$stmt = $pdo->query("SELECT COUNT(*) FROM service_requests WHERE status IN ('pending', 'negotiating')");
$stats['pending_requests'] = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM orders WHERE status IN ('scheduled', 'in_progress')");
$stats['active_orders'] = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM bills WHERE status = 'disputed'");
$stats['disputed_bills'] = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM bills WHERE status = 'paid' AND MONTH(paid_at) = MONTH(CURRENT_DATE)");
$stats['monthly_revenue'] = $stmt->fetchColumn();
?>

<h2><i class="bi bi-speedometer2"></i> Admin Dashboard</h2>
<p class="text-muted">Welcome, <?= htmlspecialchars($_SESSION['admin_name']) ?>!</p>

<!-- Stats Cards -->
<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card bg-warning">
            <div class="card-body">
                <h3><?= $stats['pending_requests'] ?></h3>
                <p class="mb-0">Pending Requests</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-info text-white">
            <div class="card-body">
                <h3><?= $stats['active_orders'] ?></h3>
                <p class="mb-0">Active Orders</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-danger text-white">
            <div class="card-body">
                <h3><?= $stats['disputed_bills'] ?></h3>
                <p class="mb-0">Disputed Bills</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-success text-white">
            <div class="card-body">
                <h3><?= formatMoney($stats['monthly_revenue']) ?></h3>
                <p class="mb-0">This Month Revenue</p>
            </div>
        </div>
    </div>
</div>

<!-- Pending Requests -->
<div class="card mb-4">
    <div class="card-header bg-warning">
        <h5 class="mb-0"><i class="bi bi-inbox"></i> Pending Requests (<?= count($pending_requests) ?>)</h5>
    </div>
    <div class="card-body">
        <?php if (empty($pending_requests)): ?>
            <p class="text-muted mb-0">No pending requests.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Client</th>
                            <th>Type</th>
                            <th>Date</th>
                            <th>Budget</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pending_requests as $req): ?>
                        <tr>
                            <td>#<?= $req['request_id'] ?></td>
                            <td>
                                <?= htmlspecialchars($req['first_name'] . ' ' . $req['last_name']) ?>
                                <br><small class="text-muted"><?= htmlspecialchars($req['email']) ?></small>
                            </td>
                            <td><?= getCleaningTypeName($req['cleaning_type']) ?></td>
                            <td><?= formatDate($req['preferred_date']) ?></td>
                            <td><?= formatMoney($req['proposed_budget']) ?></td>
                            <td><?= getStatusBadge($req['status']) ?></td>
                            <td>
                                <a href="view_request.php?id=<?= $req['request_id'] ?>" class="btn btn-sm btn-primary">
                                    Respond
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Active Orders -->
<div class="card mb-4">
    <div class="card-header bg-info text-white">
        <h5 class="mb-0"><i class="bi bi-calendar-check"></i> Active Orders (<?= count($active_orders) ?>)</h5>
    </div>
    <div class="card-body">
        <?php if (empty($active_orders)): ?>
            <p class="text-muted mb-0">No active orders.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Client</th>
                            <th>Type</th>
                            <th>Scheduled</th>
                            <th>Price</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($active_orders as $order): ?>
                        <tr>
                            <td>#<?= $order['order_id'] ?></td>
                            <td><?= htmlspecialchars($order['first_name'] . ' ' . $order['last_name']) ?></td>
                            <td><?= getCleaningTypeName($order['cleaning_type']) ?></td>
                            <td>
                                <?= formatDate($order['scheduled_date']) ?>
                                <br><small><?= formatTime($order['scheduled_time_start']) ?></small>
                            </td>
                            <td><?= formatMoney($order['final_price']) ?></td>
                            <td><?= getStatusBadge($order['status']) ?></td>
                            <td>
                                <a href="manage_order.php?id=<?= $order['order_id'] ?>" class="btn btn-sm btn-info">
                                    Manage
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Pending/Disputed Bills -->
<?php if (!empty($pending_bills)): ?>
<div class="card">
    <div class="card-header bg-danger text-white">
        <h5 class="mb-0"><i class="bi bi-exclamation-triangle"></i> Pending/Disputed Bills (<?= count($pending_bills) ?>)</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Bill #</th>
                        <th>Client</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pending_bills as $bill): ?>
                    <tr>
                        <td>#<?= $bill['bill_id'] ?></td>
                        <td><?= htmlspecialchars($bill['first_name'] . ' ' . $bill['last_name']) ?></td>
                        <td><?= formatMoney($bill['amount']) ?></td>
                        <td><?= getStatusBadge($bill['status']) ?></td>
                        <td><?= formatDate($bill['created_at']) ?></td>
                        <td>
                            <a href="manage_bill.php?id=<?= $bill['bill_id'] ?>" class="btn btn-sm btn-danger">
                                Review
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>
