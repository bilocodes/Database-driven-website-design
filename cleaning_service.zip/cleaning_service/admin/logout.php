<?php
require_once '../includes/auth.php';
logoutAdmin();
header('Location: /cleaning_service/');
exit;
?>
