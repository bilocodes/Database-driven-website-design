<?php
$pageTitle = 'Manage Order - Admin';
require_once '../config/database.php';
require_once '../includes/header.php';
requireAdminLogin();

$order_id = (int)($_GET['id'] ?? 0);

// Get order with full details
$stmt = $pdo->prepare("
    SELECT o.*, sr.*, c.first_name, c.last_name, c.email, c.phone
    FROM orders o
    JOIN service_requests sr ON o.request_id = sr.request_id
    JOIN clients c ON sr.client_id = c.client_id
    WHERE o.order_id = ?
");
$stmt->execute([$order_id]);
$order = $stmt->fetch();

if (!$order) {
    setFlashMessage('danger', 'Order not found.');
    header('Location: dashboard.php');
    exit;
}

// Get bills for this order
$stmt = $pdo->prepare("SELECT * FROM bills WHERE order_id = ? ORDER BY created_at DESC");
$stmt->execute([$order_id]);
$bills = $stmt->fetchAll();

$errors = [];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'start') {
        $stmt = $pdo->prepare("UPDATE orders SET status = 'in_progress' WHERE order_id = ?");
        $stmt->execute([$order_id]);

        setFlashMessage('info', 'Order marked as in progress.');
        header('Location: manage_order.php?id=' . $order_id);
        exit;

    } elseif ($action === 'complete') {
        $stmt = $pdo->prepare("UPDATE orders SET status = 'completed', completed_at = NOW() WHERE order_id = ?");
        $stmt->execute([$order_id]);

        setFlashMessage('success', 'Order marked as completed! You can now create a bill.');
        header('Location: manage_order.php?id=' . $order_id);
        exit;

    } elseif ($action === 'create_bill') {
        $amount = (float)($_POST['amount'] ?? 0);
        $description = sanitize($_POST['description'] ?? '');

        if ($amount < 1) {
            $errors[] = "Bill amount must be at least $1";
        } else {
            $stmt = $pdo->prepare("INSERT INTO bills (order_id, amount, description) VALUES (?, ?, ?)");
            $stmt->execute([$order_id, $amount, $description]);

            setFlashMessage('success', 'Bill created successfully!');
            header('Location: manage_order.php?id=' . $order_id);
            exit;
        }

    } elseif ($action === 'cancel') {
        $stmt = $pdo->prepare("UPDATE orders SET status = 'canceled' WHERE order_id = ?");
        $stmt->execute([$order_id]);

        setFlashMessage('info', 'Order has been canceled.');
        header('Location: dashboard.php');
        exit;
    }
}
?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Order #<?= $order_id ?></li>
    </ol>
</nav>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php foreach ($errors as $error): ?>
                <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-lg-8">
        <!-- Order Details -->
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="bi bi-clipboard-check"></i> Order #<?= $order_id ?></h5>
                <?= getStatusBadge($order['status']) ?>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Client</h6>
                        <p><strong>Name:</strong> <?= htmlspecialchars($order['first_name'] . ' ' . $order['last_name']) ?></p>
                        <p><strong>Email:</strong> <a href="mailto:<?= htmlspecialchars($order['email']) ?>"><?= htmlspecialchars($order['email']) ?></a></p>
                        <p><strong>Phone:</strong> <a href="tel:<?= htmlspecialchars($order['phone']) ?>"><?= htmlspecialchars($order['phone']) ?></a></p>
                    </div>
                    <div class="col-md-6">
                        <h6>Service</h6>
                        <p><strong>Type:</strong> <?= getCleaningTypeName($order['cleaning_type']) ?></p>
                        <p><strong>Rooms:</strong> <?= $order['num_rooms'] ?></p>
                        <p><strong>Price:</strong> <span class="fs-4 text-success"><?= formatMoney($order['final_price']) ?></span></p>
                    </div>
                </div>
                <hr>
                <p><strong>Address:</strong> <?= htmlspecialchars($order['service_address']) ?></p>
                <p><strong>Scheduled:</strong> <?= formatDate($order['scheduled_date']) ?> | <?= formatTime($order['scheduled_time_start']) ?> - <?= formatTime($order['scheduled_time_end']) ?></p>
                
                <?php if ($order['notes']): ?>
                    <hr>
                    <p><strong>Special Instructions:</strong></p>
                    <div class="alert alert-light"><?= nl2br(htmlspecialchars($order['notes'])) ?></div>
                <?php endif; ?>

                <hr>
                <small class="text-muted">
                    Created: <?= formatDateTime($order['created_at']) ?>
                    <?php if ($order['completed_at']): ?>
                        <br>Completed: <?= formatDateTime($order['completed_at']) ?>
                    <?php endif; ?>
                </small>
            </div>
        </div>

        <!-- Bills -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-receipt"></i> Bills</h5>
            </div>
            <div class="card-body">
                <?php if (empty($bills)): ?>
                    <p class="text-muted">
                        <?php if ($order['status'] === 'completed'): ?>
                            No bills created yet. Create one now!
                        <?php else: ?>
                            Complete the order first to create a bill.
                        <?php endif; ?>
                    </p>
                <?php else: ?>
                    <?php foreach ($bills as $bill): ?>
                    <div class="border rounded p-3 mb-3">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h5>Bill #<?= $bill['bill_id'] ?> - <?= formatMoney($bill['amount']) ?></h5>
                                <p class="text-muted mb-1"><?= htmlspecialchars($bill['description'] ?? 'Cleaning service') ?></p>
                                <small class="text-muted">Created: <?= formatDateTime($bill['created_at']) ?></small>
                            </div>
                            <div class="text-end">
                                <?= getStatusBadge($bill['status']) ?>
                                <br>
                                <a href="manage_bill.php?id=<?= $bill['bill_id'] ?>" class="btn btn-sm btn-outline-primary mt-2">
                                    Manage
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Actions Sidebar -->
    <div class="col-lg-4">
        <!-- Status Actions -->
        <?php if ($order['status'] === 'scheduled'): ?>
        <div class="card mb-3">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">Order Actions</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="">
                    <input type="hidden" name="action" value="start">
                    <button type="submit" class="btn btn-info w-100 mb-2">
                        <i class="bi bi-play-circle"></i> Start Service
                    </button>
                </form>
                <form method="POST" action="" onsubmit="return confirm('Cancel this order?');">
                    <input type="hidden" name="action" value="cancel">
                    <button type="submit" class="btn btn-outline-danger w-100">
                        <i class="bi bi-x-circle"></i> Cancel Order
                    </button>
                </form>
            </div>
        </div>

        <?php elseif ($order['status'] === 'in_progress'): ?>
        <div class="card mb-3">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0">Complete Service</h5>
            </div>
            <div class="card-body">
                <p>When cleaning is finished, mark the order as complete.</p>
                <form method="POST" action="">
                    <input type="hidden" name="action" value="complete">
                    <button type="submit" class="btn btn-success w-100">
                        <i class="bi bi-check-circle"></i> Mark Complete
                    </button>
                </form>
            </div>
        </div>

        <?php elseif ($order['status'] === 'completed'): ?>
        <!-- Create Bill -->
        <div class="card mb-3">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="bi bi-receipt"></i> Create Bill</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="">
                    <input type="hidden" name="action" value="create_bill">
                    
                    <div class="mb-3">
                        <label class="form-label">Amount ($)</label>
                        <div class="input-group">
                            <span class="input-group-text">$</span>
                            <input type="number" name="amount" class="form-control" 
                                   min="1" step="0.01" value="<?= $order['final_price'] ?>" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control" rows="2" 
                                  placeholder="e.g., Deep cleaning service, 5 rooms"><?= getCleaningTypeName($order['cleaning_type']) ?> - <?= $order['num_rooms'] ?> rooms</textarea>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-plus-circle"></i> Create Bill
                    </button>
                </form>
            </div>
        </div>
        <?php endif; ?>

        <!-- Order Status -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Order Status</h5>
            </div>
            <div class="card-body">
                <div class="status-timeline">
                    <div class="status-step <?= in_array($order['status'], ['scheduled', 'in_progress', 'completed']) ? 'completed' : '' ?>">
                        <i class="bi bi-calendar-check"></i> Scheduled
                    </div>
                    <div class="status-step <?= in_array($order['status'], ['in_progress', 'completed']) ? 'completed' : '' ?>">
                        <i class="bi bi-gear"></i> In Progress
                    </div>
                    <div class="status-step <?= $order['status'] === 'completed' ? 'completed' : '' ?>">
                        <i class="bi bi-check-circle"></i> Completed
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
