<?php
$pageTitle = 'View Request - Admin';
require_once '../config/database.php';
require_once '../includes/header.php';
requireAdminLogin();

$request_id = (int)($_GET['id'] ?? 0);

// Get request with client info
$stmt = $pdo->prepare("
    SELECT sr.*, c.first_name, c.last_name, c.email, c.phone, c.address as client_address
    FROM service_requests sr
    JOIN clients c ON sr.client_id = c.client_id
    WHERE sr.request_id = ?
");
$stmt->execute([$request_id]);
$request = $stmt->fetch();

if (!$request) {
    setFlashMessage('danger', 'Request not found.');
    header('Location: dashboard.php');
    exit;
}

// Get photos
$stmt = $pdo->prepare("SELECT * FROM request_photos WHERE request_id = ?");
$stmt->execute([$request_id]);
$photos = $stmt->fetchAll();

// Get quote responses (conversation history)
$stmt = $pdo->prepare("SELECT * FROM quote_responses WHERE request_id = ? ORDER BY created_at ASC");
$stmt->execute([$request_id]);
$responses = $stmt->fetchAll();

$errors = [];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'quote') {
        $adjusted_price = (float)($_POST['adjusted_price'] ?? 0);
        $scheduled_date = sanitize($_POST['scheduled_date'] ?? '');
        $scheduled_time_start = sanitize($_POST['scheduled_time_start'] ?? '');
        $scheduled_time_end = sanitize($_POST['scheduled_time_end'] ?? '');
        $note = sanitize($_POST['note'] ?? '');

        // Validation
        if ($adjusted_price < 1) $errors[] = "Price must be at least $1";
        if (empty($scheduled_date)) $errors[] = "Date is required";
        if (empty($scheduled_time_start) || empty($scheduled_time_end)) $errors[] = "Time window is required";

        if (empty($errors)) {
            $stmt = $pdo->prepare("INSERT INTO quote_responses 
                (request_id, responder, response_type, adjusted_price, scheduled_date, scheduled_time_start, scheduled_time_end, note) 
                VALUES (?, 'anna', 'quote', ?, ?, ?, ?, ?)");
            $stmt->execute([$request_id, $adjusted_price, $scheduled_date, $scheduled_time_start, $scheduled_time_end, $note]);

            $stmt = $pdo->prepare("UPDATE service_requests SET status = 'negotiating' WHERE request_id = ?");
            $stmt->execute([$request_id]);

            setFlashMessage('success', 'Quote sent successfully!');
            header('Location: view_request.php?id=' . $request_id);
            exit;
        }

    } elseif ($action === 'reject') {
        $note = sanitize($_POST['note'] ?? '');
        if (empty($note)) {
            $errors[] = "Please provide a reason for rejection.";
        } else {
            $stmt = $pdo->prepare("INSERT INTO quote_responses (request_id, responder, response_type, note) VALUES (?, 'anna', 'rejection', ?)");
            $stmt->execute([$request_id, $note]);

            $stmt = $pdo->prepare("UPDATE service_requests SET status = 'rejected' WHERE request_id = ?");
            $stmt->execute([$request_id]);

            setFlashMessage('info', 'Request rejected.');
            header('Location: dashboard.php');
            exit;
        }
    }
}
?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Request #<?= $request_id ?></li>
    </ol>
</nav>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php foreach ($errors as $error): ?>
                <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="row">
    <!-- Request Details -->
    <div class="col-lg-8">
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="bi bi-file-text"></i> Request #<?= $request_id ?></h5>
                <?= getStatusBadge($request['status']) ?>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Client Information</h6>
                        <p><strong>Name:</strong> <?= htmlspecialchars($request['first_name'] . ' ' . $request['last_name']) ?></p>
                        <p><strong>Email:</strong> <a href="mailto:<?= htmlspecialchars($request['email']) ?>"><?= htmlspecialchars($request['email']) ?></a></p>
                        <p><strong>Phone:</strong> <a href="tel:<?= htmlspecialchars($request['phone']) ?>"><?= htmlspecialchars($request['phone']) ?></a></p>
                    </div>
                    <div class="col-md-6">
                        <h6>Service Details</h6>
                        <p><strong>Type:</strong> <?= getCleaningTypeName($request['cleaning_type']) ?></p>
                        <p><strong>Rooms:</strong> <?= $request['num_rooms'] ?></p>
                        <p><strong>Proposed Budget:</strong> <span class="fs-5"><?= formatMoney($request['proposed_budget']) ?></span></p>
                    </div>
                </div>
                <hr>
                <p><strong>Service Address:</strong> <?= htmlspecialchars($request['service_address']) ?></p>
                <p><strong>Preferred Date:</strong> <?= formatDate($request['preferred_date']) ?></p>
                <p><strong>Preferred Time:</strong> <?= formatTime($request['preferred_time']) ?></p>
                
                <?php if ($request['notes']): ?>
                    <hr>
                    <p><strong>Special Instructions:</strong></p>
                    <div class="alert alert-light"><?= nl2br(htmlspecialchars($request['notes'])) ?></div>
                <?php endif; ?>

                <hr>
                <small class="text-muted">Submitted: <?= formatDateTime($request['created_at']) ?></small>
            </div>
        </div>

        <!-- Photos -->
        <?php if (!empty($photos)): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-images"></i> Photos (<?= count($photos) ?>)</h5>
            </div>
            <div class="card-body">
                <div class="row g-2">
                    <?php foreach ($photos as $photo): ?>
                    <div class="col-4 col-md-3">
                        <a href="../uploads/photos/<?= htmlspecialchars($photo['file_path']) ?>" target="_blank">
                            <img src="../uploads/photos/<?= htmlspecialchars($photo['file_path']) ?>" 
                                 class="img-fluid rounded" alt="Request photo">
                        </a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Conversation History -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-chat-dots"></i> Quote History</h5>
            </div>
            <div class="card-body">
                <?php if (empty($responses)): ?>
                    <p class="text-muted">No responses yet. Send a quote or reject the request.</p>
                <?php else: ?>
                    <div class="timeline">
                        <?php foreach ($responses as $resp): ?>
                        <div class="timeline-item <?= $resp['responder'] === 'anna' ? 'anna' : 'client' ?>">
                            <div class="timeline-badge">
                                <i class="bi bi-<?= $resp['responder'] === 'anna' ? 'person-badge' : 'person' ?>"></i>
                            </div>
                            <div class="timeline-content">
                                <div class="d-flex justify-content-between">
                                    <strong><?= $resp['responder'] === 'anna' ? 'You (Anna)' : 'Client' ?></strong>
                                    <small class="text-muted"><?= formatDateTime($resp['created_at']) ?></small>
                                </div>
                                
                                <?php if ($resp['response_type'] === 'quote'): ?>
                                    <div class="alert alert-info mt-2 mb-0">
                                        <strong>Quote:</strong> <?= formatMoney($resp['adjusted_price']) ?><br>
                                        <strong>Schedule:</strong> <?= formatDate($resp['scheduled_date']) ?> 
                                        <?= formatTime($resp['scheduled_time_start']) ?> - <?= formatTime($resp['scheduled_time_end']) ?>
                                        <?php if ($resp['note']): ?>
                                            <br><strong>Note:</strong> <?= htmlspecialchars($resp['note']) ?>
                                        <?php endif; ?>
                                    </div>
                                <?php elseif ($resp['response_type'] === 'rejection'): ?>
                                    <div class="alert alert-danger mt-2 mb-0">
                                        <strong>Rejected:</strong> <?= htmlspecialchars($resp['note']) ?>
                                    </div>
                                <?php elseif ($resp['response_type'] === 'accept'): ?>
                                    <div class="alert alert-success mt-2 mb-0">
                                        <strong>Quote Accepted!</strong>
                                    </div>
                                <?php else: ?>
                                    <p class="mt-2 mb-0"><?= htmlspecialchars($resp['note']) ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Actions Sidebar -->
    <div class="col-lg-4">
        <?php if (in_array($request['status'], ['pending', 'negotiating'])): ?>
        
        <!-- Send Quote -->
        <div class="card mb-3">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="bi bi-cash"></i> Send Quote</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="">
                    <input type="hidden" name="action" value="quote">
                    
                    <div class="mb-3">
                        <label class="form-label">Adjusted Price ($)</label>
                        <div class="input-group">
                            <span class="input-group-text">$</span>
                            <input type="number" name="adjusted_price" class="form-control" 
                                   min="1" step="0.01" value="<?= $request['proposed_budget'] ?>" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Scheduled Date</label>
                        <input type="date" name="scheduled_date" class="form-control" 
                               min="<?= date('Y-m-d') ?>" value="<?= $request['preferred_date'] ?>" required>
                    </div>

                    <div class="row mb-3">
                        <div class="col-6">
                            <label class="form-label">Start Time</label>
                            <input type="time" name="scheduled_time_start" class="form-control" 
                                   value="<?= $request['preferred_time'] ?>" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label">End Time</label>
                            <input type="time" name="scheduled_time_end" class="form-control" 
                                   value="<?= date('H:i', strtotime($request['preferred_time'] . ' +3 hours')) ?>" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Note (Optional)</label>
                        <textarea name="note" class="form-control" rows="2" 
                                  placeholder="Any comments about the quote..."></textarea>
                    </div>

                    <button type="submit" class="btn btn-success w-100">
                        <i class="bi bi-send"></i> Send Quote
                    </button>
                </form>
            </div>
        </div>

        <!-- Reject Request -->
        <div class="card">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0"><i class="bi bi-x-circle"></i> Reject Request</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="" onsubmit="return confirm('Are you sure you want to reject this request?');">
                    <input type="hidden" name="action" value="reject">
                    
                    <div class="mb-3">
                        <label class="form-label">Reason for Rejection</label>
                        <textarea name="note" class="form-control" rows="3" 
                                  placeholder="e.g., 'Fully booked', 'Outside service area'..." required></textarea>
                    </div>

                    <button type="submit" class="btn btn-danger w-100">
                        <i class="bi bi-x-circle"></i> Reject Request
                    </button>
                </form>
            </div>
        </div>

        <?php elseif ($request['status'] === 'accepted'): ?>
            <div class="alert alert-success">
                <h5><i class="bi bi-check-circle"></i> Accepted</h5>
                <p>This request has been converted to an order.</p>
                <a href="dashboard.php" class="btn btn-success">View Orders</a>
            </div>
        <?php elseif ($request['status'] === 'rejected'): ?>
            <div class="alert alert-danger">
                <h5><i class="bi bi-x-circle"></i> Rejected</h5>
                <p>This request was rejected.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
