<?php
$pageTitle = 'Manage Bill - Admin';
require_once '../config/database.php';
require_once '../includes/header.php';
requireAdminLogin();

$bill_id = (int)($_GET['id'] ?? 0);

// Get bill with full details
$stmt = $pdo->prepare("
    SELECT b.*, o.order_id, o.final_price, o.scheduled_date, 
           sr.service_address, sr.cleaning_type, sr.num_rooms,
           c.first_name, c.last_name, c.email, c.phone
    FROM bills b
    JOIN orders o ON b.order_id = o.order_id
    JOIN service_requests sr ON o.request_id = sr.request_id
    JOIN clients c ON sr.client_id = c.client_id
    WHERE b.bill_id = ?
");
$stmt->execute([$bill_id]);
$bill = $stmt->fetch();

if (!$bill) {
    setFlashMessage('danger', 'Bill not found.');
    header('Location: dashboard.php');
    exit;
}

// Get bill responses (dispute history)
$stmt = $pdo->prepare("SELECT * FROM bill_responses WHERE bill_id = ? ORDER BY created_at ASC");
$stmt->execute([$bill_id]);
$responses = $stmt->fetchAll();

// Get current amount (could be revised)
$current_amount = $bill['amount'];
foreach ($responses as $resp) {
    if ($resp['revised_amount']) {
        $current_amount = $resp['revised_amount'];
    }
}

$errors = [];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'revise') {
        $revised_amount = (float)($_POST['revised_amount'] ?? 0);
        $note = sanitize($_POST['note'] ?? '');

        if ($revised_amount < 0) {
            $errors[] = "Amount cannot be negative";
        } else {
            $stmt = $pdo->prepare("INSERT INTO bill_responses (bill_id, responder, response_type, revised_amount, note) VALUES (?, 'anna', 'revision', ?, ?)");
            $stmt->execute([$bill_id, $revised_amount, $note]);

            // Keep disputed status if it was disputed, otherwise pending
            if ($bill['status'] !== 'disputed') {
                $stmt = $pdo->prepare("UPDATE bills SET status = 'pending' WHERE bill_id = ?");
                $stmt->execute([$bill_id]);
            }

            setFlashMessage('success', 'Bill revised successfully!');
            header('Location: manage_bill.php?id=' . $bill_id);
            exit;
        }

    } elseif ($action === 'mark_paid') {
        $stmt = $pdo->prepare("INSERT INTO bill_responses (bill_id, responder, response_type, note) VALUES (?, 'anna', 'payment', 'Marked as paid by admin')");
        $stmt->execute([$bill_id]);

        $stmt = $pdo->prepare("UPDATE bills SET status = 'paid', paid_at = NOW() WHERE bill_id = ?");
        $stmt->execute([$bill_id]);

        setFlashMessage('success', 'Bill marked as paid!');
        header('Location: dashboard.php');
        exit;
    }
}
?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="manage_order.php?id=<?= $bill['order_id'] ?>">Order #<?= $bill['order_id'] ?></a></li>
        <li class="breadcrumb-item active">Bill #<?= $bill_id ?></li>
    </ol>
</nav>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php foreach ($errors as $error): ?>
                <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-lg-8">
        <!-- Bill Details -->
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="bi bi-receipt"></i> Bill #<?= $bill_id ?></h5>
                <?= getStatusBadge($bill['status']) ?>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Client</h6>
                        <p><strong>Name:</strong> <?= htmlspecialchars($bill['first_name'] . ' ' . $bill['last_name']) ?></p>
                        <p><strong>Email:</strong> <a href="mailto:<?= htmlspecialchars($bill['email']) ?>"><?= htmlspecialchars($bill['email']) ?></a></p>
                        <p><strong>Phone:</strong> <a href="tel:<?= htmlspecialchars($bill['phone']) ?>"><?= htmlspecialchars($bill['phone']) ?></a></p>
                    </div>
                    <div class="col-md-6">
                        <h6>Service</h6>
                        <p><strong>Order:</strong> #<?= $bill['order_id'] ?></p>
                        <p><strong>Type:</strong> <?= getCleaningTypeName($bill['cleaning_type']) ?></p>
                        <p><strong>Address:</strong> <?= htmlspecialchars($bill['service_address']) ?></p>
                        <p><strong>Date:</strong> <?= formatDate($bill['scheduled_date']) ?></p>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Original Amount:</strong> <?= formatMoney($bill['amount']) ?></p>
                        <p><strong>Order Price:</strong> <?= formatMoney($bill['final_price']) ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Current Amount:</strong> <span class="fs-4 text-success"><?= formatMoney($current_amount) ?></span></p>
                        <p><strong>Created:</strong> <?= formatDateTime($bill['created_at']) ?></p>
                        <?php if ($bill['paid_at']): ?>
                            <p><strong>Paid:</strong> <?= formatDateTime($bill['paid_at']) ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if ($bill['description']): ?>
                    <hr>
                    <p><strong>Description:</strong> <?= nl2br(htmlspecialchars($bill['description'])) ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Dispute History -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-chat-dots"></i> Billing History</h5>
            </div>
            <div class="card-body">
                <?php if (empty($responses)): ?>
                    <p class="text-muted">No responses yet.</p>
                <?php else: ?>
                    <div class="timeline">
                        <?php foreach ($responses as $resp): ?>
                        <div class="timeline-item <?= $resp['responder'] === 'anna' ? 'anna' : 'client' ?>">
                            <div class="timeline-badge">
                                <i class="bi bi-<?= $resp['responder'] === 'anna' ? 'person-badge' : 'person' ?>"></i>
                            </div>
                            <div class="timeline-content">
                                <div class="d-flex justify-content-between">
                                    <strong><?= $resp['responder'] === 'anna' ? 'You (Anna)' : 'Client' ?></strong>
                                    <small class="text-muted"><?= formatDateTime($resp['created_at']) ?></small>
                                </div>
                                
                                <?php if ($resp['response_type'] === 'revision'): ?>
                                    <div class="alert alert-info mt-2 mb-0">
                                        <strong>Revised Amount:</strong> <?= formatMoney($resp['revised_amount']) ?>
                                        <?php if ($resp['note']): ?>
                                            <br><?= htmlspecialchars($resp['note']) ?>
                                        <?php endif; ?>
                                    </div>
                                <?php elseif ($resp['response_type'] === 'payment'): ?>
                                    <div class="alert alert-success mt-2 mb-0">
                                        <strong>Payment Received</strong>
                                    </div>
                                <?php elseif ($resp['response_type'] === 'dispute'): ?>
                                    <div class="alert alert-warning mt-2 mb-0">
                                        <strong>Dispute:</strong> <?= htmlspecialchars($resp['note']) ?>
                                    </div>
                                <?php else: ?>
                                    <p class="mt-2 mb-0"><?= htmlspecialchars($resp['note']) ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Actions Sidebar -->
    <div class="col-lg-4">
        <?php if ($bill['status'] !== 'paid'): ?>
        
        <!-- Revise Bill -->
        <div class="card mb-3">
            <div class="card-header bg-warning">
                <h5 class="mb-0"><i class="bi bi-pencil"></i> Revise Bill</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="">
                    <input type="hidden" name="action" value="revise">
                    
                    <div class="mb-3">
                        <label class="form-label">Revised Amount ($)</label>
                        <div class="input-group">
                            <span class="input-group-text">$</span>
                            <input type="number" name="revised_amount" class="form-control" 
                                   min="0" step="0.01" value="<?= $current_amount ?>" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Note</label>
                        <textarea name="note" class="form-control" rows="3" 
                                  placeholder="e.g., 'Applied 10% discount', 'Adjusted for extra work'"></textarea>
                    </div>

                    <button type="submit" class="btn btn-warning w-100">
                        <i class="bi bi-check"></i> Send Revision
                    </button>
                </form>
            </div>
        </div>

        <!-- Mark as Paid -->
        <div class="card">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="bi bi-check-circle"></i> Manual Payment</h5>
            </div>
            <div class="card-body">
                <p class="small text-muted">Use this if client paid by cash, check, or other method.</p>
                <form method="POST" action="" onsubmit="return confirm('Mark this bill as paid?');">
                    <input type="hidden" name="action" value="mark_paid">
                    <button type="submit" class="btn btn-success w-100">
                        <i class="bi bi-check-circle"></i> Mark as Paid
                    </button>
                </form>
            </div>
        </div>

        <?php else: ?>
        <div class="alert alert-success">
            <h5><i class="bi bi-check-circle"></i> Paid</h5>
            <p class="mb-0">This bill was paid on <?= formatDateTime($bill['paid_at']) ?></p>
        </div>
        <?php endif; ?>

        <?php if ($bill['status'] === 'disputed'): ?>
        <div class="alert alert-warning mt-3">
            <h5><i class="bi bi-exclamation-triangle"></i> Disputed</h5>
            <p class="mb-0">Client has disputed this bill. Review the history and send a revision if needed.</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
