<?php
$pageTitle = 'Anna Johnson Cleaning Services - Home';
require_once 'includes/header.php';
?>

<div class="row align-items-center min-vh-75">
    <div class="col-lg-6">
        <h1 class="display-4 fw-bold text-primary">Professional Home Cleaning Services</h1>
        <p class="lead">Experience spotless living with Anna Johnson's trusted cleaning services. From basic tidying to deep cleaning and move-out services.</p>
        <div class="d-grid gap-2 d-md-flex">
            <?php if (!isClientLoggedIn()): ?>
                <a href="client/register.php" class="btn btn-primary btn-lg">
                    <i class="bi bi-person-plus"></i> Get Started
                </a>
                <a href="client/login.php" class="btn btn-outline-primary btn-lg">
                    <i class="bi bi-box-arrow-in-right"></i> Client Login
                </a>
            <?php else: ?>
                <a href="client/new_request.php" class="btn btn-primary btn-lg">
                    <i class="bi bi-plus-circle"></i> Request Service
                </a>
                <a href="client/dashboard.php" class="btn btn-outline-primary btn-lg">
                    <i class="bi bi-speedometer2"></i> My Dashboard
                </a>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-lg-6 text-center">
        <div class="hero-icon">
            <i class="bi bi-house-heart display-1 text-primary"></i>
        </div>
    </div>
</div>

<hr class="my-5">

<h2 class="text-center mb-4">Our Services</h2>
<div class="row g-4">
    <div class="col-md-4">
        <div class="card h-100 service-card">
            <div class="card-body text-center">
                <i class="bi bi-brush display-4 text-primary mb-3"></i>
                <h5 class="card-title">Basic Cleaning</h5>
                <p class="card-text">Regular maintenance cleaning including dusting, vacuuming, mopping, and bathroom cleaning.</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card h-100 service-card">
            <div class="card-body text-center">
                <i class="bi bi-stars display-4 text-primary mb-3"></i>
                <h5 class="card-title">Deep Cleaning</h5>
                <p class="card-text">Thorough cleaning including appliances, baseboards, inside cabinets, and hard-to-reach areas.</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card h-100 service-card">
            <div class="card-body text-center">
                <i class="bi bi-truck display-4 text-primary mb-3"></i>
                <h5 class="card-title">Move-Out Cleaning</h5>
                <p class="card-text">Comprehensive cleaning for tenants moving out. Get your full deposit back!</p>
            </div>
        </div>
    </div>
</div>

<hr class="my-5">

<h2 class="text-center mb-4">How It Works</h2>
<div class="row g-4">
    <div class="col-md-3 text-center">
        <div class="step-circle">1</div>
        <h5>Submit Request</h5>
        <p>Tell us about your cleaning needs and preferred schedule.</p>
    </div>
    <div class="col-md-3 text-center">
        <div class="step-circle">2</div>
        <h5>Get a Quote</h5>
        <p>Receive a personalized quote based on your requirements.</p>
    </div>
    <div class="col-md-3 text-center">
        <div class="step-circle">3</div>
        <h5>Schedule Service</h5>
        <p>Accept the quote and confirm your cleaning appointment.</p>
    </div>
    <div class="col-md-3 text-center">
        <div class="step-circle">4</div>
        <h5>Enjoy Clean Home</h5>
        <p>Relax while we make your home spotless!</p>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
